function toggleSidebar() {
  var sidebar = document.querySelector(".sidebar");
  sidebar.classList.toggle("is-active");
}

	var player = document.getElementById("player");
	var block = document.getElementById("block");
	var counter=0;
	function jump(){
		if(player.classList == "animate"){return}
		player.classList.add("animate");
		setTimeout(function(){
			player.classList.remove("animate");
		},300);
	}

	//check to see if the user has collided with the obstacle div
	var checkDead = setInterval(function() {
		let playerTop = parseInt(window.getComputedStyle(player).getPropertyValue("top"));
		let blockLeft = parseInt(window.getComputedStyle(block).getPropertyValue("left"));
		if(blockLeft<20 && blockLeft>-20 && playerTop>=302){
			block.style.animation = "none";
			alert("GAME OVER. Your score is!: "+Math.floor(counter/100));
			counter=0;
			block.style.animation = "block 1s infinite linear";
			block.style.display = "none";
			document.getElementById("scoreSpan").innerHTML="GAME OVER. Your score is!: "+Math.floor(counter/100);counter=0;
			if (confirm("Play again?")) {
			window.location.reload()
			} else {
			txt = "Okay!";
			}
		}else{
			counter++;
			document.getElementById("scoreSpan").innerHTML = Math.floor(counter/100);
		}
	}, 10);

function background(){	
	document.getElementsByClassName("BGButton").style.backgroundImage = "url('sky.jpg')";
}


 //Javascript for adams form/webpage
 function validate(){
                //set valid to true - flag 
                var valid = true;
                var msge = "You have not fully completed the form, please fill in the following: ";
                //use if statements to check the data and set the message 
                if(document.getElementById("fn").value == ""){
                    msge += " You must fill in your firstname. ";
                    valid = false;
                }
                if(document.getElementById("sn").value == ""){
                    msge += " You must fill in your surname, ";
                    valid = false;
                }
                if(document.getElementById("cn").value == ""){
                    msge += " You must fill in your age, ";
                    valid = false;
                }
				if(document.getElementById("bn").value == ""){
                    msge += " You must fill in your email,";
                    valid = false;
                }
				if(document.getElementById("comments").value == ""){
                    msge += " You need to write your question in the comment box.";
                    valid = false;
                }
                if(!valid){ //!valid is the same as valid == false
                    document.getElementById("msge").innerHTML = msge;
                }
                return valid;
}