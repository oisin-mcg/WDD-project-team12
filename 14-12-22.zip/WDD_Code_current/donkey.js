
// JavaScript for the game
window.addEventListener("load", function() {
  // Get the game elements
  const game = document.querySelector(".game");
  const donkey = document.querySelector(".donkey");
  const tail = document.querySelector(".tail");

  // Generate a random position for the donkey
  const x = Math.random() * (game.offsetWidth - donkey.offsetWidth);
  const y = Math.random() * (game.offsetHeight - donkey.offsetHeight);
  donkey.style.left = x + "px";
  donkey.style.top = y + "px";

  // Set the initial position of the tail
  let tailX = 0;
  let tailY = 0;
  tail.style.left = tailX + "px";
  tail.style.top = tailY + "px";

  // Handle mouse movement
  game.addEventListener("mousemove", function(event) {
    tailX = event.pageX - game.offsetLeft - tail.offsetWidth / 2;
    tailY = event.pageY - game.offsetTop - tail.offsetHeight / 2;
    tail.style.left = tailX + "px";
    tail.style.top = tailY + "px";
  });
}
 